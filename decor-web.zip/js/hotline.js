const hotline = document.querySelector('#hotline')
hotline.innerHTML += `
<div class="hotline">
<div class="py-2">
  <a href="">
    <img src="./img/hotline-phone.png" alt="" width="50px">
  </a>
</div>   
<div  class="py-2">
  <a href="">
    <img src="./img/hotline-note.png" alt="" width="50px">
  </a>
</div>  
<div  class="py-2">
  <a href="">
    <img src="./img/hotline-zalo.png" alt="" width="50px">
  </a>
</div>  
</div>`